import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import Window from './Window.js'
import Calculadora from './Calculadora.js'

const root = ReactDOM.createRoot(document.getElementById('root'))

root.render(
  <React.StrictMode>
    <Window width={500} height={600} posX={300} posY={100} title={'Calculadora'} resizeable>
      <Calculadora />
    </Window>
  </React.StrictMode>
)

