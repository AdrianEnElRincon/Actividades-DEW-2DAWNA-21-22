import React from 'react';
import './BottonCalculadora.css'

class BottonCalculadora extends React.Component {

    render() {
        return (
            <div
                className={(this.props.isNumber) ? 'calculator-button calculator-button-number' : 'calculator-button' }
                id={'calculator-button-' + this.props.type}
                >
                    {this.props.text}
                </div>
        )
    }

}

export default BottonCalculadora