import React from "react"
import './Window.css'

class Window extends React.Component {

    constructor(props) {
        super(props)
        this.drag = this.drag.bind(this)
        this.resize = this.resize.bind(this)
        this.state = {
            x: props.posX,
            y: props.posY,
            resizeType: null
        }
        this.windowRef = React.createRef()  
    }

    drag(ev) {
        this.windowRef.current.style.top = (ev.pageY - this.state.y) + 'px'
        this.windowRef.current.style.left = (ev.pageX - this.state.x) + 'px'
    }

    handleDrag(ev) {
        const {left, top} = this.windowRef.current.getBoundingClientRect()
        this.setState({
            x: ev.pageX - left,
            y: ev.pageY - top
        })
        document.addEventListener('mousemove', this.drag)
        document.addEventListener('mouseup', () => {
            document.removeEventListener('mousemove', this.drag)
        })
    }

    resize(ev) {
        switch (this.state.resizeType) {
            case 'e':
                this.windowRef.current.style.width = Math.max(ev.pageX - this.state.x, 200) + 'px'
                break
            case 's':
                this.windowRef.current.style.height = Math.max(ev.pageY - this.state.y, 315) + 'px'
                break
            default:
                this.windowRef.current.style.width = Math.max(ev.pageX - this.state.x, 200) + 'px'
                this.windowRef.current.style.height = Math.max(ev.pageY - this.state.y, 315) + 'px'
        }
    }

    handleResize(ev, resizeType) {
        const { left, top } = this.windowRef.current.getBoundingClientRect()
        this.setState({
            x: left,
            y: top,
            resizeType: resizeType
        })
        if (this.props.resizeable) document.addEventListener('mousemove', this.resize)
        document.addEventListener('mouseup', () => {
            document.removeEventListener('mousemove', this.resize)
        })
    }

    handleClose() {
        this.setState({
            windowShouldClose: true
        })
    }
    
    componentDidMount() {
        this.windowRef.current
            .querySelector('.window-titlebar')
            .addEventListener('mousedown', (ev) => this.handleDrag(ev))
        this.windowRef.current
            .querySelector('.window-resize-e')
            .addEventListener('mousedown', (ev) => this.handleResize(ev,'e'))
        this.windowRef.current
            .querySelector('.window-resize-s')
            .addEventListener('mousedown', (ev) => this.handleResize(ev,'s'))
        this.windowRef.current
            .querySelector('.window-resize-se')
            .addEventListener('mousedown', (ev) => this.handleResize(ev,'se'))
    }

    render() {
        return (
            <div 
                ref={this.windowRef}
                draggable="false" 
                className="window-frame"
                style={{
                    width: this.props.width + 'px',
                    height: this.props.height + 'px',
                    top: this.props.posY + 'px',
                    left: this.props.posX + 'px'
                }}>
                <div className="window-titlebar">
                    <p className="window-title">{this.props.title}</p>
                </div>
                <div className="window-resize-e"></div>
                <div className="window-resize-s"></div>
                <div className="window-resize-se"></div>
                {this.props.children}
            </div>
        )
    }
}

export default Window