import React from "react"
import './Calculadora.css'
import BottonCalculadora from './BottonCalculadora.js'

class Calculadora extends React.Component {

    constructor(props) {
        super(props)
        this.handleButtonClick = this.handleButtonClick.bind(this)
        this.calculatorRef = React.createRef()
        this.state = {
            displayBuffer: '',
            numberBuffer: '',
            operationBuffer: '',
            historyBuffer: '',
            historyReset: false
        }
    }

    handleButtonClick(ev) {
        let historyReset = this.state.historyReset
        let displayBuffer = this.state.displayBuffer
        let numberBuffer = this.state.numberBuffer
        let historyBuffer = this.state.historyBuffer
        let operationBuffer = this.state.operationBuffer

        if(historyReset) {
            this.setState({
                displayBuffer: '',
                historyBuffer: '',
                historyReset: false
            })
            displayBuffer = ''
            historyBuffer = ''
        }


        if (ev.target.classList.length > 1) {
            this.setState({
                numberBuffer: numberBuffer + ev.target.innerText,
                displayBuffer: displayBuffer + ev.target.innerText,
                historyBuffer: historyBuffer + ev.target.innerText,    
            })
        } else {

            this.setState({
                historyBuffer: historyBuffer + ' ' + ev.target.innerText + ' '
            })

            switch(ev.target.id.replace('calculator-button-','')) {
                case 'add':
                    this.setState({
                        operationBuffer: operationBuffer + numberBuffer + '+',
                        displayBuffer: '',
                        numberBuffer: ''
                    })
                    break
                case 'sub':
                    this.setState({
                        operationBuffer: operationBuffer + numberBuffer + '-',
                        displayBuffer: '',
                        numberBuffer: ''
                    })
                    break
                case 'div':
                    this.setState({
                        operationBuffer: operationBuffer + numberBuffer + '/',
                        displayBuffer: '',
                        numberBuffer: ''
                    })
                    break
                case 'mul':
                    this.setState({
                        operationBuffer: operationBuffer + numberBuffer + '*',
                        displayBuffer: '',
                        numberBuffer: ''
                    })
                    break
                case 'res':
                    this.setState({
                        operationBuffer: '',
                        displayBuffer: '',
                        numberBuffer: '',
                        historyBuffer: ''
                    })
                    break
                case 'equ':
                    let result 
                    try {
                        result = +Number(eval(this.state.operationBuffer + this.state.numberBuffer)).toFixed(9)
                        this.setState({
                            displayBuffer: result,
                            historyBuffer: historyBuffer + ' = ' + result
                        })
                    } catch {
                        this.setState({
                            displayBuffer: 'ERROR'
                        })
                    }
                    this.setState({
                        historyReset: true,
                        operationBuffer: '',
                        numberBuffer: ''
                    })
                    break
                default:
                    break
            }

        }
    }

    componentDidMount() {
        this.calculatorRef.current.querySelectorAll('.calculator-button').forEach(element => element.addEventListener('click', this.handleButtonClick))
        
    }

    render() {
        return (
            <div className="calculator-body" ref={this.calculatorRef}>
                <div id="calculator-history">{this.state.historyBuffer}</div>
                <div id="calculator-display">{this.state.displayBuffer}</div>
                <div className="calculator-button-panel">
                    <BottonCalculadora isNumber={true} type={1} text={1} />
                    <BottonCalculadora isNumber={true} type={2} text={2} />
                    <BottonCalculadora isNumber={true} type={3} text={3} />
                    <BottonCalculadora isNumber={true} type={4} text={4} />
                    <BottonCalculadora isNumber={true} type={5} text={5} />
                    <BottonCalculadora isNumber={true} type={6} text={6} />
                    <BottonCalculadora isNumber={true} type={7} text={7} />
                    <BottonCalculadora isNumber={true} type={8} text={8} />
                    <BottonCalculadora isNumber={true} type={9} text={9} />
                    <BottonCalculadora isNumber={true} type={0} text={0} />
                    <BottonCalculadora isNumber={true} type={'dot'} text={'.'} />
                    <BottonCalculadora isNumber={false} type={'add'} text={'+'} />
                    <BottonCalculadora isNumber={false} type={'sub'} text={<>&minus;</>} />
                    <BottonCalculadora isNumber={false} type={'div'} text={<>&divide;</>} />
                    <BottonCalculadora isNumber={false} type={'mul'} text={<>&times;</>} />
                    <BottonCalculadora isNumber={false} type={'res'} text={'C'} />
                    <BottonCalculadora isNumber={false} type={'equ'} text={<>&#61;</>} />
                </div>
            </div>
        )
    }
}

export default Calculadora