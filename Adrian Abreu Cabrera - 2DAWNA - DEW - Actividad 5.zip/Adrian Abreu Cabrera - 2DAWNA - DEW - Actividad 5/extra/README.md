# Extra para la Actividad 5

Se duplico la tarea para Actividad 5 en el framework React
para ejecutar el projecto de React hace falta tener [Node.js](https://nodejs.org/es/)
y ejecutar el script ````npm install && npm start``` en el directorio en el que se encuentra este mismo archivo ```./extra/```